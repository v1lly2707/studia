package pl.example.movies.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pl.example.movies.Movie;
import pl.example.movies.MovieCategory;
import pl.example.movies.service.MovieCategoryService;
import pl.example.movies.service.MovieService;

@Component
@Order(1)
public class DataInitializer implements CommandLineRunner {

    private final MovieService movieService;
    private final MovieCategoryService categoryService;

    @Autowired
    public DataInitializer(MovieService movieService, MovieCategoryService categoryService) {
        this.movieService = movieService;
        this.categoryService = categoryService;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Uruchamiam DataInitializer...");


        MovieCategory action = new MovieCategory("Akcja", "Duzo emocji");
        MovieCategory comedy = new MovieCategory("Komedia", "Duzo smiechu");

        categoryService.save(action);
        categoryService.save(comedy);

        Movie m1 = new Movie("Incepcja", 2010);
        Movie m2 = new Movie("Szybcy i wsciekli 7", 2015);
        Movie m3 = new Movie("Forrest Gump", 1994);
        Movie m4 = new Movie("Kac Vegas", 2004);

        m1.setCategory(action);
        movieService.save(m1);

        m2.setCategory(action);
        movieService.save(m2);

        m3.setCategory(comedy);
        movieService.save(m3);

        m4.setCategory(comedy);
        movieService.save(m4);

        System.out.println("Dane testowe zostały zainicjowane.");
    }
}