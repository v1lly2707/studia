package pl.example.movies.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.example.movies.Movie;
import pl.example.movies.MovieCategory;
import pl.example.movies.repository.MovieRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class MovieService {

    private final MovieRepository repository;

    @Autowired
    public MovieService(MovieRepository repository) {
        this.repository = repository;
    }
    public List<Movie> findAll() {
        return repository.findAll();
    }
    public List<Movie> findAllWithCategory() {
        return repository.findAllWithCategory();
    }

    public Optional<Movie> findById(UUID id) {
        return repository.findById(id);
    }

    public Movie save(Movie movie) {
        return repository.save(movie);
    }

    public void deleteById(UUID id) {
        repository.deleteById(id);
    }

    public List<Movie> findByCategory(MovieCategory category) {
        return repository.findByCategory(category);
    }
}