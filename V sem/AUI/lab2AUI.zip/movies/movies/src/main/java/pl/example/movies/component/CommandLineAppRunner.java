package pl.example.movies.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pl.example.movies.Movie;
import pl.example.movies.MovieCategory;
import pl.example.movies.service.MovieCategoryService;
import pl.example.movies.service.MovieService;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.UUID;

@Component
@Order(2)
public class CommandLineAppRunner implements CommandLineRunner {

    private final MovieService movieService;
    private final MovieCategoryService categoryService;
    private final Scanner scanner = new Scanner(System.in);

    @Autowired
    public CommandLineAppRunner(MovieService movieService, MovieCategoryService categoryService) {
        this.movieService = movieService;
        this.categoryService = categoryService;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Witaj! Wpisz '1' aby zobaczyć komendy.");
        boolean running = true;

        while (running) {
            String command = scanner.nextLine();
            switch (command) {
                case "1":
                    printHelp();
                    break;
                case "2":
                    listCategories();
                    break;
                case "3":
                    listMovies();
                    break;
                case "4":
                    addMovie();
                    break;
                case "5":
                    deleteMovie();
                    break;
                case "6":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Nieznana komenda. Wpisz '1'.");
                    break;
            }
        }
    }

    private void printHelp() { //
        System.out.println("Dostępne komendy:");
        System.out.println("  1 - wyświetla pomoc");
        System.out.println("  2 - wyświetla wszystkie kategorie");
        System.out.println("  3 - wyświetla wszystkie filmy");
        System.out.println("  4 - dodaje nowy film");
        System.out.println("  5 - usuwa istniejący film");
        System.out.println("  6 - zamyka aplikację");
    }

    private void listCategories() { //
        System.out.println("Wszystkie kategorie:");
        List<MovieCategory> categories = categoryService.findAll();
        if (categories.isEmpty()) {
            System.out.println("Brak kategorii w bazie.");
        } else {
            categories.forEach(cat -> System.out.printf("  ID: %s, Nazwa: %s, Opis: %s%n",
                    cat.getId(), cat.getName(), cat.getDescription()));
        }
    }

    private void listMovies() { //
        System.out.println("Wszystkie filmy:");
        List<Movie> movies = movieService.findAllWithCategory();
        if (movies.isEmpty()) {
            System.out.println("Brak filmów w bazie.");
        } else {
            movies.forEach(mov -> System.out.printf("  ID: %s, Tytuł: %s, Rok: %d, Kategoria: %s%n",
                    mov.getId(), mov.getTitle(), mov.getYear(),
                    (mov.getCategory() != null ? mov.getCategory().getName() : "Brak")));
        }
    }

    private void addMovie() { //
        System.out.println("Podaj tytuł filmu:");
        String title = scanner.nextLine();

        int year = 0;
        boolean validYear = false;

        do {
            System.out.println("Podaj rok produkcji:");
            String input = scanner.nextLine();
            try {
                year = Integer.parseInt(input);

                if (year > 2025) {
                    System.out.println("Podaj rok <= 2025");
                    validYear = false;
                } else {
                    validYear = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("To nie jest liczba. Proszę podać poprawny rok (np. 2005):");
                validYear = false;
            }
        } while (!validYear);

        System.out.println("Wybierz ID kategorii z listy:");
        listCategories();
        UUID categoryId = UUID.fromString(scanner.nextLine());

        Optional<MovieCategory> categoryOpt = categoryService.findById(categoryId);
        if (categoryOpt.isPresent()) {
            Movie movie = new Movie(title, year, categoryOpt.get());
            movieService.save(movie);
            System.out.println("Film został dodany (ID: " + movie.getId() + ")");
        } else {
            System.out.println("Nie znaleziono kategorii o podanym ID. Film nie został dodany.");
        }
    }

    private void deleteMovie() { //
        System.out.println("Wybierz ID filmu do usunięcia z listy:");
        listMovies();
        UUID movieId = UUID.fromString(scanner.nextLine());

        if (movieService.findById(movieId).isPresent()) {
            movieService.deleteById(movieId);
            System.out.println("Film o ID " + movieId + " został usunięty.");
        } else {
            System.out.println("Nie znaleziono filmu o podanym ID.");
        }
    }
}