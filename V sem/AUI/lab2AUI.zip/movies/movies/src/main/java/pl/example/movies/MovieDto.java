package pl.example.movies;

public class MovieDto implements Comparable<MovieDto> {
    private String title;
    private int year;
    private String categoryName;

    public MovieDto(String title, int year, String categoryName) {
        this.title = title;
        this.year = year;
        this.categoryName = categoryName;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public String getCategoryName() {
        return categoryName;
    }

    @Override
    public int compareTo(MovieDto other) {
        return this.title.compareToIgnoreCase(other.title);
    }

    @Override
    public String toString() {
        return "MovieDto{title='" + title + "', year=" + year + ", category='" + categoryName + "'}";
    }
}
