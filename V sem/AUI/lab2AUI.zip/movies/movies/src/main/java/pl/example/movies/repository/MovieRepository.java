package pl.example.movies.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import pl.example.movies.Movie;
import pl.example.movies.MovieCategory;
import java.util.List;
import java.util.UUID;

@Repository
public interface MovieRepository extends JpaRepository<Movie, UUID> {


    List<Movie> findByCategory(MovieCategory category);
    @Query("SELECT m FROM Movie m JOIN FETCH m.category")
    List<Movie> findAllWithCategory();
}