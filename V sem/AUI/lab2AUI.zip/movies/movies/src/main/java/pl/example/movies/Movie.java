package pl.example.movies;

import java.io.Serializable;
import java.util.Objects;
import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "movies")


public class Movie implements Serializable, Comparable<Movie> {
    @Id
    private UUID id;

    @Column(name = "title")
    private String title;

    @Column(name = "production_year")
    private int year;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private MovieCategory category;

    public Movie() {}

    public Movie(String title, int year) {
        this.id = UUID.randomUUID();
        this.title = title;
        this.year = year;
    }

    public Movie(String title, int year, MovieCategory category) {
        this.id = UUID.randomUUID();
        this.title = title;
        this.year = year;
        this.category = category;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public MovieCategory getCategory() {
        return category;
    }

    public void setCategory(MovieCategory category) {
        this.category = category;
    }

    @Override
    public int compareTo(Movie other) {
        return this.title.compareToIgnoreCase(other.title);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Movie)) return false;
        Movie movie = (Movie) o;
        return Objects.equals(id, movie.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Film {tytul = '" + title + "', rok = " + year + ", gatunek = '" +
                (category != null ? category.getName() : "brak") + "'}";
    }
}
