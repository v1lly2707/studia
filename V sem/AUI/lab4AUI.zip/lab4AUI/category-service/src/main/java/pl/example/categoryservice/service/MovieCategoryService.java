package pl.example.categoryservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.example.categoryservice.model.MovieCategory;
import pl.example.categoryservice.repository.MovieCategoryRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class MovieCategoryService {

    private final MovieCategoryRepository repository;

    @Autowired
    public MovieCategoryService(MovieCategoryRepository repository) {
        this.repository = repository;
    }


    public List<MovieCategory> findAll() {
        return repository.findAll();
    }

    public Optional<MovieCategory> findById(UUID id) {
        return repository.findById(id);
    }

    public MovieCategory save(MovieCategory category) {
        return repository.save(category);
    }

    public void deleteById(UUID id) {
        repository.deleteById(id);
    }
}