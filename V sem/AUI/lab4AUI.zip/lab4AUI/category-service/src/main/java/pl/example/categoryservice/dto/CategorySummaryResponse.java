package pl.example.categoryservice.dto;

import java.util.UUID;

public record CategorySummaryResponse(UUID id, String name) {}