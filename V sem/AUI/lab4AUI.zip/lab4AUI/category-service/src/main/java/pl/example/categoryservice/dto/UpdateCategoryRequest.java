package pl.example.categoryservice.dto;

public record UpdateCategoryRequest(String name, String description) {}