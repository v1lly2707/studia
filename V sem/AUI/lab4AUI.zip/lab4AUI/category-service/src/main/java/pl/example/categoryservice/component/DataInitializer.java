package pl.example.categoryservice.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pl.example.categoryservice.model.MovieCategory;
import pl.example.categoryservice.service.MovieCategoryService;

@Component
@Order(1)
public class DataInitializer implements CommandLineRunner {

    private final MovieCategoryService categoryService;

    @Autowired
    public DataInitializer(MovieCategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Uruchamiam DataInitializer dla Category Service...");

        MovieCategory action = new MovieCategory("Akcja", "Duzo emocji");
        MovieCategory comedy = new MovieCategory("Komedia", "Duzo smiechu");

        categoryService.save(action);
        categoryService.save(comedy);

        System.out.println("Dane testowe kategorii zostały zainicjowane.");
    }
}