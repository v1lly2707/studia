package pl.example.categoryservice.dto;

public record CreateCategoryRequest(String name, String description) {}