package pl.example.categoryservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import pl.example.categoryservice.model.MovieCategory;
import pl.example.categoryservice.dto.CategoryResponse;
import pl.example.categoryservice.dto.CategorySummaryResponse;
import pl.example.categoryservice.dto.CreateCategoryRequest;
import pl.example.categoryservice.dto.UpdateCategoryRequest;
import pl.example.categoryservice.service.MovieCategoryService;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/categories")
public class MovieCategoryController {

    private static final String MOVIE_INTERNAL_URL = "http://localhost:8082/internal/categories";
    private static final String MOVIE_API_URL = "http://localhost:8082/api/movies";

    private final MovieCategoryService categoryService;
    private final RestTemplate restTemplate;

    @Autowired
    public MovieCategoryController(MovieCategoryService categoryService, RestTemplate restTemplate) {
        this.categoryService = categoryService;
        this.restTemplate = restTemplate;
    }

    private CategorySummaryResponse mapToSummaryDto(MovieCategory category) {
        return new CategorySummaryResponse(category.getId(), category.getName());
    }

    private CategoryResponse mapToFullDto(MovieCategory category) {
        return new CategoryResponse(category.getId(), category.getName(), category.getDescription());
    }

    @GetMapping
    public ResponseEntity<List<CategorySummaryResponse>> getAllCategories() {
        List<CategorySummaryResponse> summaries = categoryService.findAll().stream()
                .map(this::mapToSummaryDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(summaries);
    }


    @PostMapping
    public ResponseEntity<CategoryResponse> createCategory(@RequestBody CreateCategoryRequest request) {
        MovieCategory newCategory = new MovieCategory(request.name(), request.description());
        MovieCategory savedCategory = categoryService.save(newCategory);

        // Wysyłanie eventu REST dla nowej kategorii (Zadanie 2)
        CategorySummaryResponse summary = mapToSummaryDto(savedCategory);
        restTemplate.postForLocation(MOVIE_INTERNAL_URL + "/add", summary);

        return ResponseEntity.status(HttpStatus.CREATED).body(mapToFullDto(savedCategory));
    }

    // NOWA METODA: Delegowanie tworzenia filmu do Movie Service (Rozwiązuje błąd 404/405)
    @PostMapping("/{id}/movies")
    public ResponseEntity<String> addMovieToCategory(@PathVariable UUID id, @RequestBody Map<String, Object> requestBody) {
        // 1. Walidacja: Upewniamy się, że kategoria istnieje, zanim delegujemy
        if (categoryService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // 2. Dodanie ID kategorii do ciała żądania, aby Movie Service (8082) wiedział, do czego przypisać film
        requestBody.put("categoryId", id.toString());

        // 3. Delegacja POST do Movie Service (8082), który obsługuje rzeczywiste tworzenie filmu
        try {
            // Uwaga: Movie Service musi mieć teraz endpoint /api/movies/delegated-create (Patrz poprzednia odpowiedź)
            String url = MOVIE_API_URL + "/delegated-create";

            // Użycie exchange do przekazania całego Body i otrzymania odpowiedzi
            ResponseEntity<String> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    new HttpEntity<>(requestBody),
                    String.class
            );

            // Zwracamy odpowiedź (np. 201 Created) otrzymaną z serwisu 8082
            return ResponseEntity.status(response.getStatusCode()).body(response.getBody());

        } catch (HttpClientErrorException e) {
            // Przekazanie błędów klienta z powrotem (np. 400 Bad Request)
            return ResponseEntity.status(e.getStatusCode()).body(e.getResponseBodyAsString());
        } catch (Exception e) {
            // Błąd komunikacji
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Błąd podczas delegowania do Movie Service.");
        }
    }


    @GetMapping("/{id}")
    public ResponseEntity<CategoryResponse> getCategoryById(@PathVariable UUID id) {
        return categoryService.findById(id)
                .map(this::mapToFullDto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @PutMapping("/{id}")
    public ResponseEntity<CategoryResponse> updateCategory(@PathVariable UUID id, @RequestBody UpdateCategoryRequest request) {
        Optional<MovieCategory> categoryOpt = categoryService.findById(id);

        if (categoryOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        MovieCategory category = categoryOpt.get();
        category.setName(request.name());
        category.setDescription(request.description());
        MovieCategory updatedCategory = categoryService.save(category);

        return ResponseEntity.ok(mapToFullDto(updatedCategory));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable UUID id) {
        if (categoryService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        categoryService.deleteById(id);

        // Wysyłanie eventu REST do usunięcia kategorii (Zadanie 2)
        restTemplate.delete(MOVIE_INTERNAL_URL + "/delete/" + id);

        return ResponseEntity.noContent().build();
    }
}