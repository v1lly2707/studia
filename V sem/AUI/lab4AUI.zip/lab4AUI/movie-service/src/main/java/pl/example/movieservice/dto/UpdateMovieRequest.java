package pl.example.movieservice.dto;

public record UpdateMovieRequest(String title, int year) {}