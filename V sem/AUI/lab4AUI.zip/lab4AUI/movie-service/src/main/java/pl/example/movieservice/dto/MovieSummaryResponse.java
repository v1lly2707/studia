package pl.example.movieservice.dto;

import java.util.UUID;

public record MovieSummaryResponse(UUID id, String title) {}