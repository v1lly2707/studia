package pl.example.movieservice.dto;

public record CreateMovieRequest(String title, int year) {}