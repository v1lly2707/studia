package pl.example.movieservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pl.example.movieservice.model.Movie;
import pl.example.movieservice.model.MovieCategory;
import java.util.List;
import java.util.UUID;

@Repository
public interface MovieRepository extends JpaRepository<Movie, UUID> {

    List<Movie> findByCategory(MovieCategory category);

    @Modifying
    @Transactional
    @Query("DELETE FROM Movie m WHERE m.category = :category")
    void deleteByCategory(MovieCategory category);
}