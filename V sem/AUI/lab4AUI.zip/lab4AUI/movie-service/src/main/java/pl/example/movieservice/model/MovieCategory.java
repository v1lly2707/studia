package pl.example.movieservice.model;

import java.io.Serializable;
import java.util.Objects;
import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "movie_categories")
public class MovieCategory implements Serializable, Comparable<MovieCategory> {
    @Id
    private UUID id;

    @Column(name = "name")
    private String name;

    // USUNIĘTO: Pole description

    public MovieCategory() {}

    public MovieCategory(String name, String description) {
        this.id = UUID.randomUUID();
        this.name = name;
    }

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    @Override
    public int compareTo(MovieCategory other) { return this.name.compareToIgnoreCase(other.name); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MovieCategory)) return false;
        MovieCategory that = (MovieCategory) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() { return Objects.hash(id); }

    @Override
    public String toString() {
        return "MovieCategory{name='" + name + "'}";
    }
}