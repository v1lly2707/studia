package pl.example.movieservice.dto;

import java.util.UUID;

public record CategorySummaryResponse(UUID id, String name) {}