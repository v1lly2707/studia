package pl.example.movieservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.example.movieservice.model.MovieCategory;
import pl.example.movieservice.dto.CategorySummaryResponse;
import pl.example.movieservice.service.MovieCategoryService;
import pl.example.movieservice.service.MovieService;

import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/internal/categories")
public class InternalCategoryController {

    private final MovieCategoryService categoryService;
    private final MovieService movieService;

    @Autowired
    public InternalCategoryController(MovieCategoryService categoryService, MovieService movieService) {
        this.categoryService = categoryService;
        this.movieService = movieService;
    }

    @PostMapping("/add")
    public ResponseEntity<Void> addCategory(@RequestBody CategorySummaryResponse categoryDto) {
        MovieCategory newCategory = new MovieCategory(categoryDto.name(), null);
        newCategory.setId(categoryDto.id());
        categoryService.save(newCategory);

        System.out.println("Odebrano event: Dodano kategorię: " + newCategory.getName());
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable UUID id) {
        Optional<MovieCategory> categoryOpt = categoryService.findById(id);

        if (categoryOpt.isPresent()) {
            MovieCategory categoryToDelete = categoryOpt.get();

            movieService.deleteByCategory(categoryToDelete);

            categoryService.deleteById(id);
            System.out.println("Odebrano event: Usunięto kategorię i powiązane filmy dla ID: " + id);
        }

        return ResponseEntity.ok().build();
    }
}