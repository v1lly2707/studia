package pl.example.movieservice.dto;
import java.util.UUID;
public record CreateMovieWithCategoryRequest(String title, int year, UUID categoryId) {}