package pl.example.movies.dto;

public record UpdateMovieRequest(String title, int year) {}