package pl.example.movies.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.example.movies.Movie;
import pl.example.movies.dto.MovieResponse;
import pl.example.movies.dto.MovieSummaryResponse;
import pl.example.movies.dto.UpdateMovieRequest;
import pl.example.movies.dto.CategorySummaryResponse;
import pl.example.movies.service.MovieService;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/movies")
public class MovieController {

    private final MovieService movieService;

    @Autowired
    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    private MovieSummaryResponse mapToSummaryDto(Movie movie) {
        return new MovieSummaryResponse(movie.getId(), movie.getTitle());
    }

    private MovieResponse mapToFullDto(Movie movie) {
        var category = movie.getCategory();
        CategorySummaryResponse categoryDto = (category != null)
                ? new CategorySummaryResponse(category.getId(), category.getName())
                : null;
        return new MovieResponse(movie.getId(), movie.getTitle(), movie.getYear(), categoryDto);
    }

    @GetMapping
    public ResponseEntity<List<MovieSummaryResponse>> getAllMovies() {
        List<MovieSummaryResponse> movies = movieService.findAllWithCategory().stream()
                .map(this::mapToSummaryDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(movies);
    }


    @GetMapping("/{id}")
    public ResponseEntity<MovieResponse> getMovieById(@PathVariable UUID id) {

        Optional<Movie> movieOpt = movieService.findById(id);

        if (movieOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Movie movie = movieOpt.get();

        return ResponseEntity.ok(mapToFullDto(movie));
    }


    @PutMapping("/{id}")
    public ResponseEntity<MovieResponse> updateMovie(@PathVariable UUID id, @RequestBody UpdateMovieRequest request) {
        Optional<Movie> movieOpt = movieService.findById(id);

        if (movieOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Movie movie = movieOpt.get();
        movie.setTitle(request.title());
        movie.setYear(request.year());
        Movie updatedMovie = movieService.save(movie);

        return ResponseEntity.ok(mapToFullDto(updatedMovie));
    }



    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable UUID id) {
        if (movieService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        movieService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}