package pl.example.movies.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.example.movies.Movie;
import pl.example.movies.MovieCategory;
import pl.example.movies.dto.*;
import pl.example.movies.service.MovieCategoryService;
import pl.example.movies.service.MovieService;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/categories")
public class MovieCategoryController {

    private final MovieCategoryService categoryService;
    private final MovieService movieService;

    @Autowired
    public MovieCategoryController(MovieCategoryService categoryService, MovieService movieService) {
        this.categoryService = categoryService;
        this.movieService = movieService;
    }

    private CategorySummaryResponse mapToSummaryDto(MovieCategory category) {
        return new CategorySummaryResponse(category.getId(), category.getName());
    }

    private CategoryResponse mapToFullDto(MovieCategory category) {
        return new CategoryResponse(category.getId(), category.getName(), category.getDescription());
    }

    private MovieSummaryResponse mapToSummaryDto(Movie movie) {
        return new MovieSummaryResponse(movie.getId(), movie.getTitle());
    }

    private MovieResponse mapToFullDto(Movie movie) {
        MovieCategory category = movie.getCategory();
        CategorySummaryResponse categoryDto = (category != null)
                ? mapToSummaryDto(category)
                : null;
        return new MovieResponse(movie.getId(), movie.getTitle(), movie.getYear(), categoryDto);
    }


    @GetMapping
    public ResponseEntity<List<CategorySummaryResponse>> getAllCategories() {
        List<CategorySummaryResponse> summaries = categoryService.findAll().stream()
                .map(this::mapToSummaryDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(summaries);
    }


    @PostMapping
    public ResponseEntity<CategoryResponse> createCategory(@RequestBody CreateCategoryRequest request) {
        MovieCategory newCategory = new MovieCategory(request.name(), request.description());
        MovieCategory savedCategory = categoryService.save(newCategory);
        return ResponseEntity.status(HttpStatus.CREATED).body(mapToFullDto(savedCategory));
    }


    @GetMapping("/{id}")
    public ResponseEntity<CategoryResponse> getCategoryById(@PathVariable UUID id) {
        Optional<MovieCategory> categoryOpt = categoryService.findById(id);

        if (categoryOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(mapToFullDto(categoryOpt.get()));
    }


    @PutMapping("/{id}")
    public ResponseEntity<CategoryResponse> updateCategory(@PathVariable UUID id, @RequestBody UpdateCategoryRequest request) {
        Optional<MovieCategory> categoryOpt = categoryService.findById(id);

        if (categoryOpt.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        MovieCategory category = categoryOpt.get();
        category.setName(request.name());
        category.setDescription(request.description());
        MovieCategory updatedCategory = categoryService.save(category);

        return ResponseEntity.ok(mapToFullDto(updatedCategory));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable UUID id) {
        if (categoryService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        categoryService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/movies")
    public ResponseEntity<List<MovieSummaryResponse>> getMoviesForCategory(@PathVariable UUID id) {
        Optional<MovieCategory> categoryOpt = categoryService.findById(id);

        if (categoryOpt.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        MovieCategory category = categoryOpt.get();
        List<MovieSummaryResponse> movies = movieService.findByCategory(category).stream()
                .map(this::mapToSummaryDto)
                .collect(Collectors.toList());

        return ResponseEntity.ok(movies);
    }


    @PostMapping("/{id}/movies")
    public ResponseEntity<MovieResponse> addMovieToCategory(@PathVariable UUID id, @RequestBody CreateMovieRequest request) {
        Optional<MovieCategory> categoryOpt = categoryService.findById(id);

        if (categoryOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        MovieCategory category = categoryOpt.get();
        Movie movie = new Movie(request.title(), request.year(), category);
        Movie savedMovie = movieService.save(movie);

        return ResponseEntity.status(HttpStatus.CREATED).body(mapToFullDto(savedMovie)); //201
    }
}