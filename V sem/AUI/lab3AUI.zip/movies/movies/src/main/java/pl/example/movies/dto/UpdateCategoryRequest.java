package pl.example.movies.dto;

public record UpdateCategoryRequest(String name, String description) {}