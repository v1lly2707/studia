package pl.example.movies.dto;

import java.util.UUID;

public record CategorySummaryResponse(UUID id, String name) {}