package pl.example.movies.dto;

public record CreateCategoryRequest(String name, String description) {}