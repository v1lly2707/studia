package pl.example.movies.dto;

public record CreateMovieRequest(String title, int year) {}