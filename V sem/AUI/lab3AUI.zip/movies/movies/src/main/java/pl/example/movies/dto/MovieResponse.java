package pl.example.movies.dto;

import java.util.UUID;

public record MovieResponse(UUID id, String title, int year, CategorySummaryResponse category) {}