package pl.example.movies.dto;

import java.util.UUID;

public record MovieSummaryResponse(UUID id, String title) {}