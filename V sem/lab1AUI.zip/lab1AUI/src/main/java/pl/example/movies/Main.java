package pl.example.movies;

import java.io.*;
import java.util.*;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args)
    {
        MovieCategory action = new MovieCategory("Akcja", "Duzo emocji");
        MovieCategory comedy = new MovieCategory("Komedia", "Duzo smiechu");

        Movie m1 = new Movie("Incepcja",2010);
        Movie m2 = new Movie("Szybcy i wsciekli 7",2015);
        Movie m3 = new Movie("Forrest Gump",1994);
        Movie m4 = new Movie("Kac Vegas",2004);

        action.addMovie(m1);
        action.addMovie(m2);
        comedy.addMovie(m3);
        comedy.addMovie(m4);

        List<MovieCategory> categories = List.of(action, comedy);

        System.out.println("Kategorie i filmy");
        categories.forEach(cat -> {
            System.out.println(cat);
            cat.getMovies().forEach(System.out::println);
        });

        Set<Movie> allMovies = categories.stream().flatMap(cat -> cat.getMovies().stream()).collect(Collectors.toSet());
        System.out.println("Wszystkie filmy");
        allMovies.forEach(System.out::println);


        System.out.println("Filmy młodsze niż 2000 r. posortowane alfabetycznie po tytule");
        allMovies.stream().filter(m-> m.getYear() > 2000).sorted(Comparator.comparing(Movie::getTitle)).forEach(System.out::println);

        System.out.println("DTO");
        List<MovieDto> movieDtos = allMovies.stream().map(m -> new MovieDto(m.getTitle(), m.getYear(), m.getCategory().getName())).sorted().collect(Collectors.toList());

        movieDtos.forEach(System.out::println);

        System.out.println("serializacja");
        String filename = "categories.bin";

        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename)))
        {
            oos.writeObject(categories);
            System.out.println("Dane zostaly zapisane do pliku " + filename);

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        System.out.println("deserializacja");
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename)))
        {
            List<MovieCategory> readCategories = (List<MovieCategory>) ois.readObject();

            for(MovieCategory c: readCategories)
            {
                System.out.println(c);
                c.getMovies().forEach(System.out::println);
            }
        }
        catch (IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        System.out.println("ForkJoinPool");

        ForkJoinPool pool = new ForkJoinPool(2);

        try
        {
            pool.submit(() -> categories.parallelStream().forEach(cat -> {System.out.println("[" + Thread.currentThread().getName() + "] Kategoria: " + cat.getName()); cat.getMovies().forEach(movie -> {
                try{
                    Thread.sleep(300);
                }
                catch (InterruptedException e){
                    Thread.currentThread().interrupt();
                }
                System.out.println("   Film: " + movie.getTitle());
            });
            })
            ).get();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            pool.shutdown();
            System.out.println("Koniec ForkJoinPool");
        }



    }
}
