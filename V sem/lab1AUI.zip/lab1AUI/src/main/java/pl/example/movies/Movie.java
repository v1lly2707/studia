package pl.example.movies;

import java.io.Serializable;
import java.util.Objects;

public class Movie implements Serializable, Comparable<Movie> {
    private String title;
    private int year;
    private MovieCategory category;

    public Movie() {}

    public Movie(String title, int year) {
        this.title = title;
        this.year = year;
    }

    public Movie(String title, int year, MovieCategory category) {
        this.title = title;
        this.year = year;
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public MovieCategory getCategory() {
        return category;
    }

    public void setCategory(MovieCategory category) {
        this.category = category;
    }

    @Override
    public int compareTo(Movie other) {
        return this.title.compareToIgnoreCase(other.title);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Movie)) return false;
        Movie movie = (Movie) o;
        return year == movie.year && Objects.equals(title, movie.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, year);
    }

    @Override
    public String toString() {
        return "Film {tytul = '" + title + "', rok = " + year + ", gatunek = '" +
                (category != null ? category.getName() : "brak") + "'}";
    }
}
