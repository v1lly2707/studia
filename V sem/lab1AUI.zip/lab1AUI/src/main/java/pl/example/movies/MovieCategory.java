package pl.example.movies;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MovieCategory implements Serializable, Comparable<MovieCategory> {
    private String name;
    private String description;
    private List<Movie> movies = new ArrayList<>();

    public MovieCategory() {}

    public MovieCategory(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void addMovie(Movie movie) {
        if (!movies.contains(movie)) {
            movies.add(movie);
            movie.setCategory(this);
        }
    }

    @Override
    public int compareTo(MovieCategory other) {
        return this.name.compareToIgnoreCase(other.name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MovieCategory)) return false;
        MovieCategory that = (MovieCategory) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return "Gatunek {nazwa = '" + name + "', opis = '" + description + "', filmy = " + movies.size() + "}";
    }
}
