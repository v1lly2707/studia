SELECT * FROM AgentNieruchomosci;
UPDATE OddzialFirmy SET KodPocztowy = '99999' WHERE KodPocztowy = '00001';
SELECT * FROM AgentNieruchomosci