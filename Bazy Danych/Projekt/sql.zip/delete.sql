SELECT *FROM AgentNieruchomosci;
DELETE FROM OddzialFirmy WHERE KodPocztowy = '30002';
SELECT *FROM AgentNieruchomosci;

